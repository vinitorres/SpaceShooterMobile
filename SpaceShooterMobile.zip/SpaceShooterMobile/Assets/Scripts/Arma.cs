﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arma : MonoBehaviour {

    public GameObject projetilPrefab;
    public float intervalo;

	// Use this for initialization
    IEnumerator Start () {

        yield return new WaitForSeconds(intervalo);
        Instantiate(projetilPrefab,transform.position,transform.rotation);

        StartCoroutine(Start());
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
