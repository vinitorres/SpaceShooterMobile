﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Contador : MonoBehaviour {

    int n;
    float intervalo;

	// Use this for initialization
	void Start () {

        n = 0;
        intervalo = 1.0f;

        StartCoroutine(Contar (intervalo));
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    IEnumerator Contar(float t) {
        yield return new WaitForSeconds(t);
        n++;
        print(n);
        StartCoroutine(Contar(intervalo));
    }
}
