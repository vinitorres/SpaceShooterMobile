﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inimigo : MonoBehaviour {

    public GameObject explosaoPrefab;
    float velocidade;
    int vidas;

	// Use this for initialization
	void Start () {
        velocidade = Random.Range(0.1f, 0.3f);
        GetComponent<Rigidbody2D>().gravityScale = Random.Range(0.1f,0.5f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Instantiate(explosaoPrefab,transform.position,transform.rotation);
        Destroy(gameObject);
    }
}
